﻿namespace BehaviorSample;
public class Class1
{

}
